
import React, { useState, useEffect } from 'react';
import { AppView, UserSession, ThemeColors, AppSettings, ContentItem, ThemeMode } from './types';
import UserDashboard from './components/UserDashboard';
import AdminDashboard from './components/AdminDashboard';
import LoginScreen from './components/LoginScreen';
import SplashScreen from './components/SplashScreen';
import AdminLogin from './components/AdminLogin';

const DEFAULT_SETTINGS: AppSettings = {
  networkName: 'استراحة حماس VIP',
  contactNumber1: '777-123-456',
  contactNumber2: '733-999-000',
  adminIp: '192.168.88.100', 
  isMaintenanceMode: false,
  globalIptvUrl: '',
  apkDownloadUrl: 'http://192.168.88.10/hamas_app.apk',
  packages: [
    { id: '1', name: 'الباقة البرونزية', quota: '2 GB', duration: '24 ساعة', price: '500 ريال', color: '#818cf8' },
    { id: '2', name: 'الباقة الفضية', quota: '10 GB', duration: '7 أيام', price: '2000 ريال', color: '#c084fc' },
    { id: '3', name: 'الباقة الذهبية', quota: '30 GB', duration: '30 يوم', price: '5000 ريال', color: '#fbbf24' },
    { id: '4', name: 'باقة الملوك (VIP)', quota: 'مفتوح', duration: '30 يوم', price: '10000 ريال', color: '#22d3ee' },
  ]
};

const App: React.FC = () => {
  const [view, setView] = useState<AppView>(AppView.USER_SPLASH);
  const [session, setSession] = useState<UserSession | null>(null);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [themeMode, setThemeMode] = useState<ThemeMode>('dark');
  
  const [theme, setTheme] = useState<ThemeColors>({
    primary: '#6366f1',
    secondary: '#22d3ee',
    accent: '#d946ef',
    glow: 'rgba(99, 102, 241, 0.5)',
    isDark: true
  });

  useEffect(() => {
    const savedSettings = localStorage.getItem('hamas_settings');
    if (savedSettings) setSettings(JSON.parse(savedSettings));

    const savedTheme = localStorage.getItem('hamas_theme_mode') as ThemeMode;
    if (savedTheme) setThemeMode(savedTheme);

    if (view === AppView.USER_SPLASH) {
      const timer = setTimeout(() => setView(AppView.USER_LOGIN), 3000);
      return () => clearTimeout(timer);
    }
  }, [view]);

  const toggleTheme = () => {
    const newMode = themeMode === 'dark' ? 'light' : 'dark';
    setThemeMode(newMode);
    setTheme({ ...theme, isDark: newMode === 'dark' });
    localStorage.setItem('hamas_theme_mode', newMode);
  };

  const handleLogin = (username: string, speedType: string) => {
    setSession({
      username,
      balance: '25.0 GB',
      expiry: '2025-12-30',
      ipAddress: '192.168.88.' + Math.floor(Math.random() * 254),
      macAddress: 'DE:AD:BE:EF:CA:FE',
      speedType: speedType
    });
    setView(AppView.USER_DASHBOARD);
  };

  const updateSettings = (newSettings: AppSettings) => {
    setSettings(newSettings);
    localStorage.setItem('hamas_settings', JSON.stringify(newSettings));
  };

  const bgClass = theme.isDark ? 'bg-[#050505]' : 'bg-[#f8fafc]';

  return (
    <div className={`min-h-screen transition-colors duration-500 ${bgClass}`}>
      {view === AppView.USER_SPLASH && <SplashScreen theme={theme} />}
      
      {view === AppView.USER_LOGIN && (
        <LoginScreen 
          theme={theme}
          settings={settings}
          onLogin={handleLogin} 
          onAdminLink={() => setView(AppView.ADMIN_LOGIN)} 
          toggleTheme={toggleTheme}
        />
      )}
      
      {view === AppView.USER_DASHBOARD && session && (
        <UserDashboard 
          theme={theme}
          session={session} 
          settings={settings}
          onLogout={() => setView(AppView.USER_LOGIN)} 
          toggleTheme={toggleTheme}
        />
      )}
      
      {view === AppView.ADMIN_LOGIN && (
        <AdminLogin 
          theme={theme}
          adminIp={settings.adminIp}
          onLogin={() => setView(AppView.ADMIN_DASHBOARD)} 
          onBack={() => setView(AppView.USER_LOGIN)} 
        />
      )}
      
      {view === AppView.ADMIN_DASHBOARD && (
        <AdminDashboard 
          theme={theme} 
          settings={settings}
          setSettings={updateSettings}
          setTheme={setTheme} 
          onBack={() => setView(AppView.USER_LOGIN)}
          toggleTheme={toggleTheme}
        />
      )}
    </div>
  );
};

export default App;
