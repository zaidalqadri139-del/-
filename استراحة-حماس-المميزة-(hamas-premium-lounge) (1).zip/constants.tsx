
import { ContentItem, ConnectedUser } from './types';

export const MOCK_MOVIES: ContentItem[] = [
  {
    id: '1',
    title: 'الملحمة الكبرى',
    description: 'فيلم درامي أكشن يحكي قصة صراع البقاء في البراري.',
    poster: 'https://picsum.photos/seed/movie1/400/600',
    type: 'movie',
    category: 'أكشن محلي',
    streamUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
    isFree: true,
    isLocal: true,
    isVisible: true,
    year: 2024,
    createdAt: Date.now()
  },
  {
    id: '2',
    title: 'غموض القاهرة',
    description: 'محقق يحاول حل لغز اختفاء غامض في شوارع القاهرة القديمة.',
    poster: 'https://picsum.photos/seed/movie2/400/600',
    type: 'movie',
    category: 'تشويق محلي',
    streamUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
    isFree: true,
    isLocal: true,
    isVisible: true,
    year: 2023,
    createdAt: Date.now()
  }
];

// Added timeSpent to all mock app usage objects to align with the updated AppUsage type definition
export const MOCK_USERS: ConnectedUser[] = [
  {
    id: 'u1',
    ip: '192.168.88.54',
    mac: 'DE:AD:BE:EF:01',
    username: 'user_ahmed',
    totalData: '1.2 GB',
    status: 'active',
    usageBreakdown: [
      { appName: 'Facebook', dataUsed: '450 MB', percentage: 40, icon: '📱', timeSpent: '2h 15m' },
      { appName: 'YouTube', dataUsed: '300 MB', percentage: 25, icon: '🎬', timeSpent: '1h 30m' },
      { appName: 'TikTok', dataUsed: '250 MB', percentage: 20, icon: '🎵', timeSpent: '1h 05m' },
      { appName: 'WhatsApp', dataUsed: '100 MB', percentage: 15, icon: '💬', timeSpent: '45m' },
    ]
  },
  {
    id: 'u2',
    ip: '192.168.88.102',
    mac: 'BC:FE:D9:AA:02',
    username: 'guest_wifi',
    totalData: '850 MB',
    status: 'idle',
    usageBreakdown: [
      { appName: 'Instagram', dataUsed: '500 MB', percentage: 60, icon: '📸', timeSpent: '3h 10m' },
      { appName: 'Google', dataUsed: '200 MB', percentage: 25, icon: '🌐', timeSpent: '50m' },
      { appName: 'Others', dataUsed: '150 MB', percentage: 15, icon: '⚙️', timeSpent: '20m' },
    ]
  }
];
