
export enum AppView {
  USER_SPLASH,
  USER_LOGIN,
  USER_DASHBOARD,
  USER_PLAYER,
  ADMIN_LOGIN,
  ADMIN_DASHBOARD
}

export type ThemeMode = 'dark' | 'light';

export interface ThemeColors {
  primary: string;
  secondary: string;
  accent: string;
  glow: string;
  isDark: boolean;
}

export interface AppUsage {
  appName: string;
  dataUsed: string;
  percentage: number;
  icon: string;
  timeSpent: string;
}

export interface ContentItem {
  id: string;
  title: string;
  description: string;
  poster: string;
  type: 'movie' | 'series' | 'match' | 'ad';
  category: string;
  streamUrl: string;
  isFree: boolean;
  isLocal: boolean;
  isVisible: boolean; // تحكم المدير: هل يظهر للمستخدم أم لا؟
  year?: number;
  duration?: string;
  createdAt: number;
}

// Added MatchSchedule interface to support sports schedules in the LiveMatches component
export interface MatchSchedule {
  id: string;
  teams: string;
  time: string;
  status: string;
}

export interface ConnectedUser {
  id: string;
  ip: string;
  mac: string;
  username: string;
  totalData: string;
  status: 'active' | 'idle';
  usageBreakdown: AppUsage[];
}

export interface UserSession {
  username: string;
  balance: string;
  expiry: string;
  ipAddress: string;
  macAddress: string;
  speedType: string;
  isAdmin?: boolean;
}

export interface InternetPackage {
  id: string;
  name: string;
  quota: string;
  duration: string;
  price: string;
  color: string;
}

export interface AppSettings {
  networkName: string;
  contactNumber1: string;
  contactNumber2: string;
  packages: InternetPackage[];
  adminIp: string;
  isMaintenanceMode: boolean;
  globalIptvUrl: string;
  apkDownloadUrl: string;
}
