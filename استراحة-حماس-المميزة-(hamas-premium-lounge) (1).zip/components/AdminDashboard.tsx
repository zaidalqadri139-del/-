
import React, { useState, useEffect } from 'react';
import { ThemeColors, AppSettings, ContentItem, ConnectedUser } from '../types';
import { MOCK_USERS } from '../constants';
import Logo from './Logo';

interface Props {
  theme: ThemeColors;
  settings: AppSettings;
  setSettings: (s: AppSettings) => void;
  setTheme: (t: ThemeColors) => void;
  onBack: () => void;
  toggleTheme: () => void;
}

const AdminDashboard: React.FC<Props> = ({ theme, settings, setSettings, setTheme, onBack, toggleTheme }) => {
  const [activeMenu, setActiveMenu] = useState<'stats' | 'users' | 'content' | 'settings'>('stats');
  const [items, setItems] = useState<ContentItem[]>([]);
  const [connectedUsers, setConnectedUsers] = useState<ConnectedUser[]>(MOCK_USERS);
  const [selectedUser, setSelectedUser] = useState<ConnectedUser | null>(null);

  // Form State
  const [localTitle, setLocalTitle] = useState('');
  const [localUrl, setLocalUrl] = useState('');

  useEffect(() => {
    const saved = localStorage.getItem('hamas_lounge_content');
    if (saved) setItems(JSON.parse(saved));
  }, []);

  const saveToDisk = (updatedItems: ContentItem[]) => {
    setItems(updatedItems);
    localStorage.setItem('hamas_lounge_content', JSON.stringify(updatedItems));
  };

  const toggleVisibility = (id: string) => {
    const updated = items.map(item => 
      item.id === id ? { ...item, isVisible: !item.isVisible } : item
    );
    saveToDisk(updated);
  };

  const handleAddLocal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!localTitle || !localUrl) return;
    const newItem: ContentItem = {
      id: Date.now().toString(),
      title: localTitle,
      description: 'محتوى مضاف يدوياً من الميكروتك',
      poster: `https://picsum.photos/seed/${Date.now()}/400/600`,
      type: 'movie',
      category: 'محتوى محلي',
      streamUrl: localUrl,
      isFree: true,
      isLocal: true,
      isVisible: true,
      createdAt: Date.now()
    };
    saveToDisk([newItem, ...items]);
    setLocalTitle(''); setLocalUrl('');
    alert('✅ تم إضافة المحتوى بنجاح');
  };

  const containerBg = theme.isDark ? 'bg-[#02040a]' : 'bg-white';
  const sidebarBg = theme.isDark ? 'bg-black/40' : 'bg-slate-100';
  const cardBg = theme.isDark ? 'bg-white/[0.03]' : 'bg-slate-50';
  const textColor = theme.isDark ? 'text-white' : 'text-slate-900';

  return (
    <div className={`flex h-screen overflow-hidden font-['Cairo'] transition-colors duration-500 ${containerBg} ${textColor}`}>
      {/* Sidebar */}
      <aside className={`w-80 border-l border-white/5 flex flex-col p-8 z-50 ${sidebarBg}`}>
        <Logo size={70} theme={theme} className="mb-10 mx-auto" />
        <nav className="flex-1 space-y-2">
           <AdminNavItem label="الإحصائيات" icon="📊" active={activeMenu === 'stats'} onClick={() => setActiveMenu('stats')} theme={theme} />
           <AdminNavItem label="مراقبة الأجهزة" icon="📡" active={activeMenu === 'users'} onClick={() => setActiveMenu('users')} theme={theme} />
           <AdminNavItem label="إدارة المحتوى" icon="🎬" active={activeMenu === 'content'} onClick={() => setActiveMenu('content')} theme={theme} />
           <AdminNavItem label="الإعدادات" icon="⚙️" active={activeMenu === 'settings'} onClick={() => setActiveMenu('settings')} theme={theme} />
        </nav>
        
        <div className="mt-auto space-y-4">
           <button onClick={toggleTheme} className={`w-full py-4 rounded-2xl font-black text-xs flex items-center justify-center gap-3 border border-white/10 ${cardBg}`}>
              {theme.isDark ? '🌙 الوضع الليلي' : '☀️ الوضع النهاري'}
           </button>
           <button onClick={onBack} className="w-full py-4 bg-red-500/10 text-red-500 rounded-2xl font-black text-xs uppercase border border-red-500/20">خروج</button>
        </div>
      </aside>

      {/* Main Area */}
      <main className="flex-1 overflow-y-auto p-12 custom-scrollbar">
        {activeMenu === 'users' && (
          <div className="animate-fade-in space-y-10">
             <div className="flex justify-between items-end">
                <h2 className="text-4xl font-black italic">مراقبة <span className="text-cyan-500">الأجهزة المتصلة</span></h2>
                <span className="text-xs bg-cyan-500/20 text-cyan-500 px-4 py-2 rounded-full font-black animate-pulse">MikroTik Deep Packet Inspection</span>
             </div>

             <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Users List */}
                <div className="lg:col-span-2 space-y-4">
                   {connectedUsers.map(user => (
                     <div 
                       key={user.id} 
                       onClick={() => setSelectedUser(user)}
                       className={`${cardBg} p-6 rounded-3xl border border-white/5 flex justify-between items-center cursor-pointer hover:border-cyan-500/50 transition-all ${selectedUser?.id === user.id ? 'ring-2 ring-cyan-500' : ''}`}
                     >
                        <div className="flex items-center gap-6">
                           <div className={`w-3 h-3 rounded-full ${user.status === 'active' ? 'bg-green-500 animate-ping' : 'bg-gray-500'}`}></div>
                           <div>
                              <p className="font-black text-lg">{user.ip}</p>
                              <p className="text-[10px] text-gray-500 font-bold uppercase">{user.mac} • {user.username}</p>
                           </div>
                        </div>
                        <div className="text-right">
                           <p className="text-xl font-black">{user.totalData}</p>
                           <p className="text-[10px] text-gray-500 uppercase font-black">إجمالي الاستهلاك</p>
                        </div>
                     </div>
                   ))}
                </div>

                {/* Usage Detail */}
                <div className={`${cardBg} p-8 rounded-[40px] border border-white/10 h-fit sticky top-0`}>
                   {selectedUser ? (
                     <div className="space-y-8 animate-fade-in">
                        <div className="text-center">
                           <h3 className="text-xl font-black">تحليل التطبيقات {selectedUser.ip}</h3>
                        </div>
                        <div className="space-y-6">
                           {selectedUser.usageBreakdown.map((app, i) => (
                             <div key={i} className="space-y-2">
                                <div className="flex justify-between text-xs font-black">
                                   <span>{app.icon} {app.appName}</span>
                                   <span>{app.dataUsed}</span>
                                </div>
                                <div className="h-2 w-full bg-black/40 rounded-full overflow-hidden">
                                   <div className="h-full bg-cyan-500" style={{ width: `${app.percentage}%` }}></div>
                                </div>
                             </div>
                           ))}
                        </div>
                        <button className="w-full py-4 bg-red-600/20 text-red-500 rounded-2xl text-xs font-black border border-red-500/20">قطع الإنترنت عن هذا الجهاز ⚡</button>
                     </div>
                   ) : (
                     <div className="text-center py-20 opacity-30 italic font-bold">يرجى اختيار جهاز لرؤية تفاصيل الاستهلاك لكل تطبيق</div>
                   )}
                </div>
             </div>
          </div>
        )}

        {activeMenu === 'content' && (
          <div className="animate-fade-in space-y-12">
             {/* Add Content Form */}
             <div className={`${theme.isDark ? 'bg-indigo-600/10' : 'bg-indigo-50'} p-10 rounded-[40px] border border-indigo-500/20 flex flex-col md:flex-row gap-6 items-center`}>
                <div className="flex-1">
                   <h3 className="text-2xl font-black mb-2">إضافة محتوى محلي (مجاني)</h3>
                   <p className="text-sm opacity-60">سيظهر هذا المحتوى في قسم "سينما الميكروتك".</p>
                </div>
                <form onSubmit={handleAddLocal} className="flex flex-col md:flex-row gap-4 w-full md:w-auto">
                   <input className={`${theme.isDark ? 'bg-black/40' : 'bg-white'} border border-white/10 rounded-xl px-6 py-4 outline-none text-sm`} placeholder="اسم الفيلم" value={localTitle} onChange={e => setLocalTitle(e.target.value)} />
                   <input className={`${theme.isDark ? 'bg-black/40' : 'bg-white'} border border-white/10 rounded-xl px-6 py-4 outline-none text-sm`} placeholder="رابط الملف المحلي" value={localUrl} onChange={e => setLocalUrl(e.target.value)} />
                   <button className="bg-indigo-600 px-8 py-4 rounded-xl font-black text-white">حفظ 💾</button>
                </form>
             </div>

             {/* Content Visibility Control */}
             <div className="space-y-6">
                <h3 className="text-xl font-black">🎛️ إدارة المحتوى المعروض للمشتركين</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                   {items.map(item => (
                     <div key={item.id} className={`${cardBg} p-6 rounded-3xl border border-white/5 flex justify-between items-center group`}>
                        <div className="flex items-center gap-4">
                           <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl ${item.isLocal ? 'bg-green-500/20' : 'bg-blue-500/20'}`}>
                              {item.isLocal ? '🏠' : '📡'}
                           </div>
                           <div>
                              <p className={`font-black ${!item.isVisible ? 'opacity-30 line-through' : ''}`}>{item.title}</p>
                              <p className="text-[10px] font-bold opacity-40 uppercase">{item.isLocal ? 'محلي (مجاني)' : 'أونلاين (مدفوع)'}</p>
                           </div>
                        </div>
                        <div className="flex items-center gap-4">
                           <button 
                             onClick={() => toggleVisibility(item.id)}
                             className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl transition-all ${item.isVisible ? 'bg-cyan-500/20 text-cyan-500' : 'bg-red-500/20 text-red-500'}`}
                             title={item.isVisible ? 'إخفاء عن المشتركين' : 'إظهار للمشتركين'}
                           >
                             {item.isVisible ? '👁️' : '🕶️'}
                           </button>
                           <button onClick={() => saveToDisk(items.filter(i => i.id !== item.id))} className="text-red-500/40 hover:text-red-500 text-xs font-black">حذف</button>
                        </div>
                     </div>
                   ))}
                </div>
             </div>
          </div>
        )}

        {activeMenu === 'stats' && (
           <div className="animate-fade-in grid grid-cols-1 md:grid-cols-4 gap-6">
              <StatCard label="المتصلين الآن" value={connectedUsers.filter(u => u.status === 'active').length} icon="🟢" color="#22c55e" theme={theme} />
              <StatCard label="أفلام محلية" value={items.filter(i => i.isLocal).length} icon="🏠" color="#3b82f6" theme={theme} />
              <StatCard label="قنوات VIP" value={items.filter(i => !i.isLocal).length} icon="📡" color="#a855f7" theme={theme} />
              <StatCard label="إجمالي الاستهلاك اليومي" value="142 GB" icon="📈" color="#f97316" theme={theme} />
           </div>
        )}
      </main>
    </div>
  );
};

const AdminNavItem = ({ label, icon, active, onClick, theme }: any) => (
  <button onClick={onClick} className={`w-full flex items-center gap-6 px-8 py-5 rounded-3xl transition-all ${active ? 'bg-indigo-600 text-white shadow-xl' : (theme.isDark ? 'text-gray-500 hover:text-white' : 'text-slate-400 hover:text-slate-900')}`}>
    <span className="text-2xl">{icon}</span>
    <span className="font-black text-sm">{label}</span>
  </button>
);

const StatCard = ({ label, value, icon, color, theme }: any) => (
   <div className={`${theme.isDark ? 'bg-white/[0.03]' : 'bg-slate-50'} p-8 rounded-[40px] border border-white/5 relative overflow-hidden group hover:scale-105 transition-all`}>
      <div className="absolute top-0 right-0 w-2 h-full" style={{ backgroundColor: color }}></div>
      <p className="text-[10px] font-black opacity-40 uppercase mb-2">{label}</p>
      <div className="flex items-center gap-4">
         <span className="text-4xl font-black" style={{ color }}>{value}</span>
         <span className="text-2xl">{icon}</span>
      </div>
   </div>
);

export default AdminDashboard;
