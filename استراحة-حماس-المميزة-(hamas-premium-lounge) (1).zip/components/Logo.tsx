
import React from 'react';
import { ThemeColors } from '../types';

interface LogoProps {
  size?: number;
  theme: ThemeColors;
  className?: string;
}

const Logo: React.FC<LogoProps> = ({ size = 100, theme, className = "" }) => {
  return (
    <div className={`relative flex items-center justify-center ${className}`} style={{ width: size, height: size }}>
      {/* Outer Halo Rings */}
      <div className="absolute inset-0 rounded-full border border-cyan-500/10 animate-[spin_15s_linear_infinite]"></div>
      <div className="absolute inset-4 rounded-full border border-indigo-500/20 animate-[spin_10s_linear_infinite_reverse]"></div>
      
      {/* Central Glow */}
      <div 
        className="absolute inset-4 blur-[30px] rounded-full opacity-30 animate-pulse" 
        style={{ backgroundColor: theme.secondary }}
      ></div>

      <svg viewBox="0 0 100 100" className="relative w-full h-full drop-shadow-[0_0_15px_rgba(34,211,238,0.6)]">
        <defs>
          <linearGradient id="mainGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#6366f1" />
            <stop offset="50%" stopColor="#22d3ee" />
            <stop offset="100%" stopColor="#d946ef" />
          </linearGradient>
          <filter id="innerGlow">
            <feGaussianBlur stdDeviation="1.5" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>
        
        {/* Hexagonal Shield */}
        <path 
          d="M50 5 L92 27 L92 73 L50 95 L8 73 L8 27 Z" 
          fill="rgba(0,0,0,0.8)" 
          stroke="url(#mainGrad)" 
          strokeWidth="2.5"
          filter="url(#innerGlow)"
        />
        
        {/* Stylized Core 'H' */}
        <path 
          d="M32 35 V65 M68 35 V65 M32 50 H68" 
          stroke="url(#mainGrad)" 
          strokeWidth="7" 
          strokeLinecap="round"
          className="animate-pulse"
        />

        {/* Technical Accents */}
        <circle cx="50" cy="15" r="1.5" fill="#22d3ee" />
        <circle cx="50" cy="85" r="1.5" fill="#d946ef" />
      </svg>
    </div>
  );
};

export default Logo;
