
import React from 'react';
import { ThemeColors } from '../types';
import Logo from './Logo';

interface Props {
  theme: ThemeColors;
}

const SplashScreen: React.FC<Props> = ({ theme }) => {
  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center bg-[#02040a] z-[100] overflow-hidden">
      {/* Dynamic Cosmic Background */}
      <div className="absolute w-[600px] h-[600px] border border-cyan-500/10 rounded-full animate-[ping_5s_infinite] opacity-30"></div>
      <div className="absolute w-[400px] h-[400px] border border-indigo-500/10 rounded-full animate-[ping_7s_infinite] opacity-20"></div>
      
      <div className="relative flex items-center justify-center">
        {/* Dual Rotating Rings */}
        <div className="absolute w-64 h-64 border-[1px] border-indigo-500/30 rounded-full animate-[spin_8s_linear_infinite]"></div>
        <div className="absolute w-72 h-72 border-t-2 border-cyan-500/50 rounded-full animate-[spin_4s_linear_infinite]"></div>
        
        {/* Official Logo */}
        <Logo size={180} theme={theme} />
      </div>

      <div className="mt-20 text-center animate-fade-in">
        <h1 className="text-6xl font-black mb-4 tracking-tighter uppercase italic">
          <span className="text-white">Hamas</span> <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-cyan-400">Network</span>
        </h1>
        <p className="text-gray-600 font-bold uppercase tracking-[0.8em] text-xs">The Ultimate Digital Experience</p>
      </div>

      <div className="absolute bottom-20 flex items-center gap-6">
         <div className="h-[2px] w-12 bg-gradient-to-r from-transparent to-indigo-500"></div>
         <span className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.4em]">Initializing Core</span>
         <div className="h-[2px] w-12 bg-gradient-to-l from-transparent to-indigo-500"></div>
      </div>
    </div>
  );
};

export default SplashScreen;
