
import React, { useState } from 'react';
import Logo from './Logo';
import { ThemeColors, AppSettings } from '../types';

interface Props {
  theme: ThemeColors;
  settings: AppSettings;
  onLogin: (username: string, speedType: string) => void;
  onAdminLink: () => void;
  toggleTheme: () => void;
}

const SPEED_OPTIONS = [
  { id: 'standard', label: 'سرعة عادية', desc: 'تصفح محلي مجاني', icon: '📶', color: '#6366f1' },
  { id: 'turbo', label: 'سرعة توربو', desc: 'بث 4K فائق', icon: '🚀', color: '#22d3ee' },
];

const LoginScreen: React.FC<Props> = ({ theme, settings, onLogin, onAdminLink, toggleTheme }) => {
  const [step, setStep] = useState<1 | 2>(1);
  const [selectedSpeed, setSelectedSpeed] = useState<string | null>(null);
  const [voucher, setVoucher] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = () => {
    if (!voucher) return;
    setLoading(true);
    setTimeout(() => onLogin(voucher, selectedSpeed || 'standard'), 1500);
  };

  const containerBg = theme.isDark ? 'bg-[#02040a]' : 'bg-slate-50';
  const glassBg = theme.isDark ? 'bg-white/[0.01]' : 'bg-white/80';
  const textColor = theme.isDark ? 'text-white' : 'text-slate-900';

  return (
    <div className={`relative min-h-screen flex items-center justify-center p-6 font-['Cairo'] overflow-hidden transition-colors duration-500 ${containerBg}`}>
      {/* Visual Accents */}
      <div className="absolute top-[-10%] left-[-10%] w-[600px] h-[600px] bg-indigo-500/10 rounded-full blur-[120px]"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[500px] h-[500px] bg-cyan-500/10 rounded-full blur-[100px]"></div>

      <div className="absolute top-8 right-8 z-[100]">
         <button onClick={toggleTheme} className="w-14 h-14 rounded-full bg-white/5 backdrop-blur-xl flex items-center justify-center text-2xl border border-white/10 hover:scale-110 transition-transform">
            {theme.isDark ? '☀️' : '🌙'}
         </button>
      </div>

      <div className="w-full max-w-lg relative z-10">
         <div className={`${glassBg} backdrop-blur-[40px] border border-white/10 p-12 rounded-[60px] shadow-2xl relative overflow-hidden group`}>
            <div className="flex flex-col items-center mb-12">
               <Logo size={step === 1 ? 130 : 100} theme={theme} />
               <h2 className={`text-3xl font-black mt-6 tracking-tighter ${textColor}`}>{settings.networkName}</h2>
               <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mt-1">Hamas Premium Hub V3</p>
            </div>

            {step === 1 ? (
              <div className="animate-fade-in space-y-4">
                 <p className="text-center text-xs font-black text-gray-500 uppercase mb-6">اختر وضع الاتصال المفضل</p>
                 {SPEED_OPTIONS.map(opt => (
                   <button
                     key={opt.id}
                     onClick={() => { setSelectedSpeed(opt.id); setStep(2); }}
                     className={`w-full p-6 rounded-[30px] border border-white/5 flex items-center gap-6 transition-all hover:scale-[1.03] ${theme.isDark ? 'bg-black/40 hover:bg-black/60' : 'bg-white hover:bg-slate-50 shadow-md'}`}
                   >
                     <div className="text-3xl">{opt.icon}</div>
                     <div className="text-right flex-1">
                        <p className={`font-black text-xl leading-none mb-1 ${textColor}`}>{opt.label}</p>
                        <p className="text-[9px] text-gray-500 uppercase font-bold">{opt.desc}</p>
                     </div>
                   </button>
                 ))}
              </div>
            ) : (
              <div className="animate-fade-in space-y-8">
                 <div className="space-y-4">
                    <p className="text-center text-[10px] font-black text-indigo-500 uppercase tracking-widest">أدخل رمز المرور للمتابعة</p>
                    <input
                      type="text"
                      value={voucher}
                      onChange={(e) => setVoucher(e.target.value)}
                      placeholder="CARD CODE"
                      className={`w-full bg-black/40 border border-white/10 rounded-[35px] py-10 text-center text-4xl font-black outline-none focus:border-indigo-500 transition-all shadow-inner tracking-widest ${textColor}`}
                    />
                 </div>
                 <button
                   onClick={handleLogin}
                   disabled={loading || !voucher}
                   className="w-full py-8 bg-gradient-to-r from-indigo-600 to-cyan-600 rounded-[35px] font-black text-2xl text-white shadow-xl shadow-indigo-600/30 hover:brightness-110 active:scale-95 transition-all"
                 >
                   {loading ? 'جاري العبور...' : 'دخول الملوك 🚀'}
                 </button>
                 <button onClick={() => setStep(1)} className="w-full text-gray-500 text-[9px] font-black uppercase tracking-widest hover:text-indigo-400">↩ تغيير السرعة</button>
              </div>
            )}

            <div className="mt-12 pt-8 border-t border-white/5 text-center">
               <button onClick={onAdminLink} className="text-[9px] font-black text-gray-600 hover:text-indigo-400 uppercase tracking-[0.4em]">
                  🛡️ بوابة الإدارة المركزية
               </button>
            </div>
         </div>
      </div>
    </div>
  );
};

export default LoginScreen;
