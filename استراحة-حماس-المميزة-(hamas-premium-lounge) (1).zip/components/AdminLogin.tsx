
import React, { useState, useEffect } from 'react';
import { ThemeColors } from '../types';

interface Props {
  theme: ThemeColors;
  adminIp: string;
  onLogin: () => void;
  onBack: () => void;
}

const AdminLogin: React.FC<Props> = ({ theme, adminIp, onLogin, onBack }) => {
  const [pass, setPass] = useState('');
  const [status, setStatus] = useState<'idle' | 'checking' | 'failed' | 'success'>('idle');
  const [currentIp, setCurrentIp] = useState('0.0.0.0');

  useEffect(() => {
    // محاكاة الحصول على الـ IP من الراوتر
    setCurrentIp('192.168.88.' + (Math.random() > 0.5 ? '100' : '55'));
  }, []);

  const handleLogin = () => {
    setStatus('checking');
    
    // محاكاة التحقق من الميكروتك
    setTimeout(() => {
      // الشرط: كلمة المرور صحيحة + الـ IP يطابق IP المدير المسجل في ميكروتك
      if (pass === 'admin123' && currentIp === adminIp) {
        setStatus('success');
        setTimeout(onLogin, 1000);
      } else {
        setStatus('failed');
        setTimeout(() => setStatus('idle'), 3000);
      }
    }, 2000);
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen px-6 bg-[#020617] font-['Cairo'] relative overflow-hidden">
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/asfalt-dark.png')] opacity-10"></div>
      
      <div className="w-full max-w-md bg-white/[0.03] backdrop-blur-3xl p-12 rounded-[50px] shadow-2xl border border-white/10 relative z-10">
        <div className="text-center mb-10">
          <div className="w-24 h-24 rounded-[30px] flex items-center justify-center mx-auto mb-6 shadow-[0_0_40px_rgba(0,255,65,0.3)] bg-black/50 border border-green-500/30">
             <span className="text-5xl">{status === 'checking' ? '🔄' : status === 'failed' ? '🚫' : '🛡️'}</span>
          </div>
          <h2 className="text-3xl font-black text-white mb-2">مصادقة المسؤول</h2>
          <p className="text-gray-500 text-[10px] font-bold uppercase tracking-[0.3em]">MikroTik System Identity Check</p>
        </div>

        <div className="bg-black/40 p-4 rounded-2xl mb-8 border border-white/5 flex justify-between items-center">
           <div>
              <p className="text-[9px] font-black text-gray-500 uppercase">IP الجهاز المكتشف</p>
              <p className={`text-sm font-mono font-bold ${currentIp === adminIp ? 'text-green-500' : 'text-red-500'}`}>{currentIp}</p>
           </div>
           <div className={`text-[10px] px-3 py-1 rounded-full font-black ${currentIp === adminIp ? 'bg-green-500/10 text-green-500' : 'bg-red-500/10 text-red-500'}`}>
              {currentIp === adminIp ? 'هوية موثوقة' : 'هوية مجهولة'}
           </div>
        </div>

        {currentIp === adminIp ? (
          <div className="space-y-6 animate-fade-in">
            <div className="relative">
              <input
                type="password"
                value={pass}
                onChange={(e) => setPass(e.target.value)}
                placeholder="أدخل كلمة مرور النظام"
                className="w-full bg-black/60 border border-white/10 rounded-2xl py-5 px-6 text-center text-white focus:border-green-500 outline-none transition-all shadow-inner font-black tracking-widest"
              />
            </div>
            <button
              onClick={handleLogin}
              disabled={status === 'checking'}
              className="w-full font-black py-5 rounded-2xl transition-all shadow-2xl hover:brightness-110 active:scale-95 flex items-center justify-center gap-3 overflow-hidden relative group"
              style={{ backgroundColor: theme.secondary, color: '#000' }}
            >
              {status === 'checking' ? (
                <div className="w-6 h-6 border-4 border-black/20 border-t-black rounded-full animate-spin"></div>
              ) : (
                <>
                  <span>ولوج لوحة التحكم</span>
                  <span className="text-xl">🔑</span>
                </>
              )}
            </button>
          </div>
        ) : (
          <div className="p-6 bg-red-500/10 border border-red-500/20 rounded-3xl text-center animate-bounce">
             <p className="text-red-500 font-black text-sm">عذراً! جهازك غير مخول بالدخول.</p>
             <p className="text-[10px] text-red-400/60 mt-2 uppercase">Your IP must be registered in MikroTik Admin List</p>
          </div>
        )}

        {status === 'failed' && (
          <p className="text-center text-red-500 text-xs font-black mt-4 animate-pulse">خطأ في كلمة المرور أو الهوية!</p>
        )}

        <button 
          onClick={onBack} 
          className="mt-10 text-gray-500 text-[10px] font-black hover:text-white block mx-auto transition-colors uppercase tracking-widest"
        >
          ⬅ عودة لواجهة المشتركين
        </button>
      </div>
    </div>
  );
};

export default AdminLogin;
