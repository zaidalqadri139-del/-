
import React, { useState, useEffect } from 'react';
import { UserSession, ContentItem, ThemeColors, AppSettings } from '../types';
import ContentCard from './ContentCard';
import VideoPlayer from './VideoPlayer';
import Logo from './Logo';

interface Props {
  theme: ThemeColors;
  session: UserSession;
  settings: AppSettings;
  onLogout: () => void;
  toggleTheme: () => void;
}

const UserDashboard: React.FC<Props> = ({ theme, session, settings, onLogout, toggleTheme }) => {
  const [items, setItems] = useState<ContentItem[]>([]);
  const [activeTab, setActiveTab] = useState<'local' | 'online'>('local');
  const [playingVideo, setPlayingVideo] = useState<ContentItem | null>(null);

  useEffect(() => {
    const updateContent = () => {
      const saved = localStorage.getItem('hamas_lounge_content');
      if (saved) setItems(JSON.parse(saved));
    };
    updateContent();
  }, []);

  if (playingVideo) {
    return <VideoPlayer content={playingVideo} onClose={() => setPlayingVideo(null)} />;
  }

  // تصفية المحتوى بناءً على حالة الظهور (التي حددها المدير) والتبويب المختار
  const filteredItems = items.filter(i => {
    if (!i.isVisible) return false;
    if (activeTab === 'local') return i.isLocal;
    if (activeTab === 'online') return !i.isLocal;
    return true;
  });

  const containerBg = theme.isDark ? 'bg-[#020617]' : 'bg-slate-50';
  const headerBg = theme.isDark ? 'bg-black/40' : 'bg-white';
  const textColor = theme.isDark ? 'text-white' : 'text-slate-900';

  return (
    <div className={`flex flex-col h-screen overflow-hidden font-['Cairo'] transition-colors duration-500 ${containerBg} ${textColor}`}>
      {/* Network Status Header */}
      <div className="bg-gradient-to-r from-cyan-600/20 to-transparent border-b border-white/5 px-6 py-2 flex justify-between items-center z-[60]">
         <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse"></div>
            <span className="text-[10px] font-black text-cyan-500 uppercase tracking-widest">متصل بالشبكة المحلية ( MikroTik Secure )</span>
         </div>
         <button onClick={toggleTheme} className="text-xl hover:scale-110 transition-transform">
            {theme.isDark ? '☀️' : '🌙'}
         </button>
      </div>

      <header className={`p-8 border-b border-white/5 flex justify-between items-center z-50 backdrop-blur-3xl ${headerBg}`}>
        <div className="flex items-center gap-6">
           <Logo size={55} theme={theme} />
           <div>
              <h1 className="text-2xl font-black tracking-tighter uppercase">{settings.networkName}</h1>
              <p className="text-[9px] font-black text-indigo-500 uppercase tracking-[0.4em]">Entertainment Hub</p>
           </div>
        </div>
        <div className="flex items-center gap-6">
           <div className="text-right">
              <span className="text-[8px] font-black text-gray-500 uppercase tracking-widest block">الرصيد</span>
              <span className="text-xl font-black">{session.balance}</span>
           </div>
           <button onClick={onLogout} className="w-12 h-12 bg-red-500/10 text-red-500 rounded-xl flex items-center justify-center hover:bg-red-500 hover:text-white transition-all">🚪</button>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto pb-40 p-6 md:p-12 custom-scrollbar">
        {/* Tab Selection */}
        <div className="flex justify-center mb-12">
           <div className={`p-2 rounded-[30px] flex gap-2 ${theme.isDark ? 'bg-black/40' : 'bg-white shadow-xl'} border border-white/5`}>
              <button 
                onClick={() => setActiveTab('local')}
                className={`px-10 py-5 rounded-[25px] font-black text-sm transition-all flex items-center gap-3 ${activeTab === 'local' ? 'bg-cyan-600 text-white shadow-lg' : 'text-gray-500 hover:text-gray-300'}`}
              >
                🏠 سينما الميكروتك (مجاني)
              </button>
              <button 
                onClick={() => setActiveTab('online')}
                className={`px-10 py-5 rounded-[25px] font-black text-sm transition-all flex items-center gap-3 ${activeTab === 'online' ? 'bg-indigo-600 text-white shadow-lg' : 'text-gray-500 hover:text-gray-300'}`}
              >
                📡 القنوات المباشرة (مدفوع)
              </button>
           </div>
        </div>

        {filteredItems.length === 0 ? (
          <div className="text-center py-40 opacity-40 italic">
             <div className="text-8xl mb-6">🔭</div>
             <h3 className="text-2xl font-black">لا يوجد محتوى متاح حالياً في هذا القسم</h3>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-10">
             {filteredItems.map(item => (
               <ContentCard key={item.id} item={item} onClick={() => setPlayingVideo(item)} />
             ))}
          </div>
        )}
      </main>

      {/* Floating User Info */}
      <div className="fixed bottom-8 left-0 right-0 flex justify-center pointer-events-none">
         <div className={`pointer-events-auto px-12 py-5 rounded-[40px] flex items-center gap-12 border border-white/10 shadow-2xl backdrop-blur-2xl ${headerBg}`}>
            <div className="flex items-center gap-4">
               <div className="w-10 h-10 bg-indigo-500 rounded-xl flex items-center justify-center shadow-lg">👤</div>
               <div>
                  <p className="text-[8px] font-black text-gray-500 uppercase">المشترك</p>
                  <p className="text-xs font-black">{session.username}</p>
               </div>
            </div>
            <div className="h-8 w-[1px] bg-white/10"></div>
            <div className="flex items-center gap-4">
               <div className="w-10 h-10 bg-cyan-500 rounded-xl flex items-center justify-center shadow-lg">📶</div>
               <div>
                  <p className="text-[8px] font-black text-gray-500 uppercase">السرعة</p>
                  <p className="text-xs font-black">{session.speedType.toUpperCase()}</p>
               </div>
            </div>
         </div>
      </div>
    </div>
  );
};

export default UserDashboard;
