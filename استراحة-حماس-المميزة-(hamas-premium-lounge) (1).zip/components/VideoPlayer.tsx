
import React from 'react';
import { ContentItem } from '../types';

interface Props {
  content: ContentItem;
  onClose: () => void;
}

const VideoPlayer: React.FC<Props> = ({ content, onClose }) => {
  return (
    <div className="fixed inset-0 bg-black z-[100] flex flex-col animate-fade-in">
      {/* Dynamic Player Header */}
      <div className="absolute top-0 inset-x-0 p-8 bg-gradient-to-b from-black/95 to-transparent flex justify-between items-start z-[110]">
        <div className="flex gap-6 items-start">
          <button 
            onClick={onClose} 
            className="group w-14 h-14 bg-white/10 hover:bg-[#d4af37] backdrop-blur-md rounded-2xl flex items-center justify-center transition-all duration-500 shadow-2xl active:scale-90"
          >
            <span className="text-2xl text-white group-hover:text-black transition-colors">←</span>
          </button>
          <div>
            <div className="flex items-center gap-3 mb-1">
               <span className="bg-[#d4af37] text-black text-[9px] font-black px-2 py-0.5 rounded uppercase">{content.category}</span>
               <h2 className="text-2xl font-black text-white">{content.title}</h2>
            </div>
            <p className="text-xs text-gray-400 font-bold tracking-widest uppercase">Lounge Streaming Mode • 4K HDR</p>
          </div>
        </div>
        
        <div className="flex flex-col items-end gap-2">
           <div className="px-4 py-2 bg-green-500/10 border border-green-500/20 rounded-full flex items-center gap-2">
              <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
              <span className="text-[10px] font-black text-green-500 uppercase tracking-widest">Local Link Secure</span>
           </div>
           <span className="text-[9px] text-gray-500 font-bold uppercase tracking-tighter">Server ID: HAMAS-MKT-01</span>
        </div>
      </div>

      {/* Video Canvas */}
      <div className="flex-1 relative flex items-center justify-center bg-[#050505]">
        <video 
          src={content.streamUrl} 
          controls 
          autoPlay 
          className="w-full h-full object-contain shadow-[0_0_100px_rgba(0,0,0,1)]"
          poster={content.poster}
        />
        
        {/* Anti-Recording Watermark */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none opacity-[0.03] select-none rotate-12">
           <p className="text-[120px] font-black text-white whitespace-nowrap tracking-[0.5em]">HAMAS PREMIUM LOUNGE</p>
        </div>
      </div>

      {/* Interactive Info Bar */}
      <div className="bg-[#0c0c0c] border-t border-white/5 p-12">
        <div className="max-w-5xl mx-auto flex gap-12">
           <div className="flex-1">
              <h3 className="text-xl font-black gold-text mb-4 border-r-4 border-[#d4af37] pr-4">ملخص العرض</h3>
              <p className="text-gray-400 leading-loose text-lg font-medium">{content.description}</p>
           </div>
           <div className="w-72 space-y-4">
              <div className="p-6 bg-white/5 rounded-3xl border border-white/5">
                 <p className="text-[10px] text-gray-500 font-black mb-1">تاريخ الإنتاج</p>
                 <p className="text-xl font-black">{content.year}</p>
              </div>
              <div className="p-6 bg-[#d4af37]/10 rounded-3xl border border-[#d4af37]/20">
                 <p className="text-[10px] gold-text font-black mb-1">التوفير المالي</p>
                 <p className="text-xl font-black">مجاني بالكامل</p>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default VideoPlayer;
