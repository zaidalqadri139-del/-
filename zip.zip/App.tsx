
import React, { useState, useEffect } from 'react';
import { AppView, UserSession, ThemeColors } from './types';
import UserDashboard from './components/UserDashboard';
import AdminDashboard from './components/AdminDashboard';
import LoginScreen from './components/LoginScreen';
import SplashScreen from './components/SplashScreen';
import AdminLogin from './components/AdminLogin';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>(AppView.USER_SPLASH);
  const [session, setSession] = useState<UserSession | null>(null);
  
  // Dynamic Theme Management
  const [theme, setTheme] = useState<ThemeColors>({
    primary: '#0047AB', // Royal Blue
    secondary: '#00FF41', // Matrix Green
    accent: '#00D4FF',
    glow: 'rgba(0, 255, 65, 0.4)'
  });

  useEffect(() => {
    if (view === AppView.USER_SPLASH) {
      const timer = setTimeout(() => setView(AppView.USER_LOGIN), 2500);
      return () => clearTimeout(timer);
    }
  }, [view]);

  const handleLogin = (username: string, speedType: string) => {
    setSession({
      username,
      balance: '25.0 GB',
      expiry: '2025-12-30',
      ipAddress: '10.0.0.55',
      macAddress: 'DE:AD:BE:EF:CA:FE',
      speedType: speedType // Storing the user's choice
    });
    setView(AppView.USER_DASHBOARD);
  };

  const handleAdminLogin = () => {
    setView(AppView.ADMIN_DASHBOARD);
  };

  // Back Button Logic
  const goBack = (target: AppView) => setView(target);

  return (
    <div 
      className="min-h-screen text-gray-200 transition-colors duration-1000"
      style={{ backgroundColor: '#020617', backgroundImage: `radial-gradient(circle at top right, ${theme.primary}11, transparent), radial-gradient(circle at bottom left, ${theme.secondary}11, transparent)` }}
    >
      {view === AppView.USER_SPLASH && <SplashScreen theme={theme} />}
      
      {view === AppView.USER_LOGIN && (
        <LoginScreen 
          theme={theme}
          onLogin={handleLogin} 
          onAdminLink={() => setView(AppView.ADMIN_LOGIN)} 
        />
      )}
      
      {view === AppView.USER_DASHBOARD && session && (
        <UserDashboard 
          theme={theme}
          session={session} 
          onLogout={() => setView(AppView.USER_LOGIN)} 
        />
      )}
      
      {view === AppView.ADMIN_LOGIN && (
        <AdminLogin 
          theme={theme}
          onLogin={handleAdminLogin} 
          onBack={() => setView(AppView.USER_LOGIN)} 
        />
      )}
      
      {view === AppView.ADMIN_DASHBOARD && (
        <AdminDashboard 
          theme={theme} 
          setTheme={setTheme} 
          onBack={() => setView(AppView.ADMIN_LOGIN)}
        />
      )}
    </div>
  );
};

export default App;
