
import React, { useState, useEffect } from 'react';
import { UserSession, ContentItem, ThemeColors } from '../types';
import ContentCard from './ContentCard';
import VideoPlayer from './VideoPlayer';
import Logo from './Logo';

interface Props {
  theme: ThemeColors;
  session: UserSession;
  onLogout: () => void;
}

const UserDashboard: React.FC<Props> = ({ theme, session, onLogout }) => {
  const [items, setItems] = useState<ContentItem[]>([]);
  const [activeTab, setActiveTab] = useState<'all' | 'movies' | 'matches'>('all');
  const [playingVideo, setPlayingVideo] = useState<ContentItem | null>(null);
  const [latency, setLatency] = useState(12);

  useEffect(() => {
    const updateContent = () => {
      const saved = localStorage.getItem('hamas_lounge_content');
      if (saved) setItems(JSON.parse(saved));
    };

    updateContent();
    const interval = setInterval(() => {
      updateContent();
      setLatency(Math.floor(Math.random() * 5) + 3); // سرعة استجابة الميكروتك عالية جداً
    }, 5000);
    
    return () => clearInterval(interval);
  }, []);

  if (playingVideo) {
    return <VideoPlayer content={playingVideo} onClose={() => setPlayingVideo(null)} />;
  }

  const filteredItems = items.filter(i => {
    if (activeTab === 'movies') return i.type === 'movie' || i.type === 'series';
    if (activeTab === 'matches') return i.type === 'match';
    return true;
  });

  return (
    <div className="flex flex-col h-screen bg-[#020617] text-white font-['Cairo'] overflow-hidden">
      {/* Dynamic Network Status Bar */}
      <div className="bg-gradient-to-r from-green-600/20 to-transparent border-b border-white/5 px-6 py-2 flex justify-between items-center z-[60]">
         <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5">
               <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
               <span className="text-[10px] font-black text-green-500 uppercase tracking-widest">Local Node Active</span>
            </div>
            <div className="h-3 w-[1px] bg-white/10"></div>
            <span className="text-[10px] font-black text-gray-500 uppercase">IP: {session.ipAddress}</span>
         </div>
         <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
               <span className="text-[10px] font-black text-gray-500 uppercase">Response:</span>
               <span className="text-[10px] font-black text-green-400">{latency}ms</span>
            </div>
            <div className="flex items-center gap-1">
               <div className="w-1 h-2 bg-green-500/50 rounded-full"></div>
               <div className="w-1 h-3 bg-green-500/80 rounded-full"></div>
               <div className="w-1 h-4 bg-green-500 rounded-full"></div>
            </div>
         </div>
      </div>

      <header className="p-8 bg-black/40 backdrop-blur-3xl border-b border-white/5 flex justify-between items-center z-50">
        <div className="flex items-center gap-8">
           <Logo size={60} theme={theme} />
           <div>
              <h1 className="text-2xl font-black tracking-tighter">استراحة حماس</h1>
              <p className="text-[10px] text-gray-500 font-bold uppercase tracking-[0.5em] mt-1">Hamas Premium Hub</p>
           </div>
        </div>

        <div className="flex items-center gap-10">
           <div className="hidden md:flex flex-col items-end">
              <span className="text-[9px] font-black text-gray-500 uppercase tracking-widest">رصيدك الحالي</span>
              <span className="text-2xl font-black text-white" style={{ textShadow: `0 0 20px ${theme.secondary}44` }}>{session.balance}</span>
           </div>
           <button onClick={onLogout} className="w-14 h-14 bg-white/5 rounded-2xl flex items-center justify-center hover:bg-red-500/10 hover:text-red-500 transition-all border border-white/5 shadow-xl group">
              <span className="text-2xl group-hover:-translate-x-1 transition-transform">🚪</span>
           </button>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto pb-40 custom-scrollbar p-8 lg:p-16">
        {items.length === 0 ? (
          <div className="h-[60vh] flex flex-col items-center justify-center text-center animate-fade-in">
             <div className="relative">
                <div className="absolute inset-0 bg-green-500 blur-[60px] opacity-20 animate-pulse"></div>
                <div className="w-40 h-40 bg-white/5 rounded-full flex items-center justify-center mb-10 border border-white/10 relative z-10">
                   <span className="text-6xl animate-bounce">📡</span>
                </div>
             </div>
             <h2 className="text-4xl font-black mb-4">بوابة المحتوى <span style={{ color: theme.secondary }}>شاغرة</span></h2>
             <p className="text-gray-500 font-bold max-w-md text-lg leading-relaxed">المدير لم يقم بإضافة أي أفلام أو قنوات حتى الآن. يرجى الانتظار، سيتم التحديث تلقائياً عند النشر.</p>
          </div>
        ) : (
          <div className="space-y-16 animate-fade-in">
            {/* Filter Hub */}
            <div className="flex flex-col md:flex-row justify-between items-end gap-6 border-b border-white/5 pb-8">
               <div className="flex gap-4">
                  <UserTabButton label="الرئيسية" active={activeTab === 'all'} onClick={() => setActiveTab('all')} theme={theme} />
                  <UserTabButton label="أفلام الميكروتك" active={activeTab === 'movies'} onClick={() => setActiveTab('movies')} theme={theme} />
                  <UserTabButton label="بث مباشر LIVE" active={activeTab === 'matches'} onClick={() => setActiveTab('matches')} theme={theme} />
               </div>
               <div className="text-right">
                  <p className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] mb-1">المحتوى المتوفر</p>
                  <p className="text-xs font-black text-white bg-white/5 px-4 py-1 rounded-full border border-white/5">{filteredItems.length} عنصر نشط</p>
               </div>
            </div>

            {/* Interactive Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-10">
               {filteredItems.map(item => (
                 <ContentCard key={item.id} item={item} onClick={() => setPlayingVideo(item)} />
               ))}
            </div>
          </div>
        )}
      </main>

      {/* Modern Floating User Info */}
      <div className="fixed bottom-8 left-8 right-8 pointer-events-none flex justify-center">
         <div className="bg-black/80 backdrop-blur-2xl border border-white/10 px-10 py-5 rounded-[40px] flex items-center gap-12 pointer-events-auto shadow-[0_30px_60px_rgba(0,0,0,0.5)]">
            <div className="flex items-center gap-4 border-l border-white/10 pl-12">
               <div className="w-10 h-10 bg-green-500 rounded-xl flex items-center justify-center text-xl shadow-[0_0_20px_rgba(34,197,94,0.4)]">👤</div>
               <div>
                  <p className="text-[9px] font-black text-gray-500 uppercase tracking-widest leading-none mb-1">المشترك</p>
                  <p className="text-xs font-black text-white">{session.username}</p>
               </div>
            </div>
            <div className="flex items-center gap-4 border-l border-white/10 pl-12">
               <div className="w-10 h-10 bg-blue-500 rounded-xl flex items-center justify-center text-xl shadow-[0_0_20px_rgba(59,130,246,0.4)]">⚡</div>
               <div>
                  <p className="text-[9px] font-black text-gray-500 uppercase tracking-widest leading-none mb-1">وضع السرعة</p>
                  <p className="text-xs font-black text-white uppercase">{session.speedType}</p>
               </div>
            </div>
            <div className="flex items-center gap-4">
               <div className="w-10 h-10 bg-yellow-500 rounded-xl flex items-center justify-center text-xl shadow-[0_0_20px_rgba(234,179,8,0.4)]">📅</div>
               <div>
                  <p className="text-[9px] font-black text-gray-500 uppercase tracking-widest leading-none mb-1">تاريخ الانتهاء</p>
                  <p className="text-xs font-black text-white">{session.expiry}</p>
               </div>
            </div>
         </div>
      </div>
    </div>
  );
};

const UserTabButton = ({ label, active, onClick, theme }: any) => (
  <button onClick={onClick} className={`px-10 py-4 rounded-2xl font-black text-sm transition-all relative overflow-hidden group ${active ? 'bg-white text-black shadow-2xl scale-105' : 'bg-white/5 text-gray-500 hover:text-white'}`}>
    {active && <div className="absolute top-0 left-0 w-full h-1 bg-green-500"></div>}
    {label}
  </button>
);

export default UserDashboard;
