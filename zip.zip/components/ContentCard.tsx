
import React from 'react';
import { ContentItem } from '../types';

interface Props {
  item: ContentItem;
  onClick: () => void;
}

const ContentCard: React.FC<Props> = ({ item, onClick }) => {
  const isLive = item.type === 'match';

  return (
    <div onClick={onClick} className="group relative cursor-pointer flex flex-col gap-4">
      <div className="relative aspect-[3/4.5] rounded-[40px] overflow-hidden bg-white/5 border border-white/10 transition-all duration-500 group-hover:-translate-y-4 group-hover:shadow-[0_30px_60px_rgba(0,0,0,0.6)] group-hover:border-green-500/30">
        <img src={item.poster} className="w-full h-full object-cover transition-transform duration-[1.5s] group-hover:scale-110 opacity-80 group-hover:opacity-100" alt={item.title} />
        
        {/* Dynamic Badge */}
        <div className="absolute top-5 right-5">
           <div className={`backdrop-blur-xl border border-white/20 text-[9px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest shadow-2xl flex items-center gap-2 ${isLive ? 'bg-red-600/80 text-white' : 'bg-black/60 text-gray-300'}`}>
             {isLive && <span className="w-1.5 h-1.5 bg-white rounded-full animate-ping"></span>}
             {isLive ? 'LIVE' : item.type}
           </div>
        </div>

        {/* Local/Cloud Icon */}
        <div className="absolute bottom-5 left-5 w-10 h-10 bg-black/40 backdrop-blur-md rounded-2xl flex items-center justify-center border border-white/10 opacity-0 group-hover:opacity-100 transition-opacity">
           <span className="text-xl">{item.category.includes('محلي') ? '📟' : '📡'}</span>
        </div>
        
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-60"></div>
      </div>
      
      <div className="px-2 transition-all group-hover:translate-x-2">
        <h4 className="text-lg font-black text-white leading-tight mb-1 truncate">{item.title}</h4>
        <div className="flex items-center gap-2">
           <span className="text-[9px] font-black text-gray-500 uppercase tracking-widest bg-white/5 px-2 py-0.5 rounded-lg">{item.category}</span>
        </div>
      </div>
    </div>
  );
};

export default ContentCard;
