
import React, { useState, useEffect } from 'react';
import { ThemeColors, ContentItem } from '../types';
import Logo from './Logo';

interface Props {
  theme: ThemeColors;
  setTheme: (t: ThemeColors) => void;
  onBack: () => void;
}

const AdminDashboard: React.FC<Props> = ({ theme, setTheme, onBack }) => {
  const [activeMenu, setActiveMenu] = useState<'stats' | 'content' | 'mikrotik' | 'servers'>('content');
  const [items, setItems] = useState<ContentItem[]>([]);
  const [sourceType, setSourceType] = useState<'mikrotik' | 'external'>('mikrotik');
  
  const [newItem, setNewItem] = useState<Partial<ContentItem>>({
    type: 'movie',
    isFree: true,
    category: 'أكشن',
    streamUrl: 'http://192.168.88.10/media/' // افتراضي للميكروتك
  });

  useEffect(() => {
    const saved = localStorage.getItem('hamas_lounge_content');
    if (saved) setItems(JSON.parse(saved));
  }, []);

  const saveContent = (updated: ContentItem[]) => {
    setItems(updated);
    localStorage.setItem('hamas_lounge_content', JSON.stringify(updated));
  };

  const handleAddItem = () => {
    if (!newItem.title || !newItem.streamUrl) return;
    const item: ContentItem = {
      ...(newItem as ContentItem),
      id: Math.random().toString(36).substr(2, 9),
      createdAt: Date.now(),
      // إذا كان من الميكروتك نضمن أنه محلي
      category: sourceType === 'mikrotik' ? `محلي - ${newItem.category}` : `بث مباشر - ${newItem.category}`
    };
    saveContent([item, ...items]);
    setNewItem({ type: 'movie', isFree: true, category: 'أكشن', streamUrl: 'http://192.168.88.10/media/' });
  };

  const removeItem = (id: string) => {
    saveContent(items.filter(i => i.id !== id));
  };

  return (
    <div className="flex h-screen bg-[#020617] text-white overflow-hidden font-['Cairo']">
      {/* Sidebar Sidebar */}
      <aside className="w-80 bg-black/80 backdrop-blur-3xl border-l border-white/5 flex flex-col p-8 z-50">
        <div className="flex items-center gap-4 mb-12">
           <Logo size={50} theme={theme} />
           <div>
              <h1 className="text-sm font-black text-white leading-none">الإدارة المركزية</h1>
              <p className="text-[9px] text-green-500 font-bold mt-1 uppercase">Hamas Core v3.1</p>
           </div>
        </div>

        <nav className="flex-1 space-y-2">
           <AdminNavItem label="الحالة العامة" icon="📊" active={activeMenu === 'stats'} onClick={() => setActiveMenu('stats')} color={theme.secondary} />
           <AdminNavItem label="إضافة محتوى / قنوات" icon="➕" active={activeMenu === 'content'} onClick={() => setActiveMenu('content')} color={theme.secondary} />
           <AdminNavItem label="ملفات الميكروتك" icon="💾" active={activeMenu === 'mikrotik'} onClick={() => setActiveMenu('mikrotik')} color="#00D4FF" />
           <AdminNavItem label="المتصلون الآن" icon="👥" active={activeMenu === 'servers'} onClick={() => setActiveMenu('servers')} color="#FFD700" />
        </nav>

        <button onClick={onBack} className="mt-auto py-4 bg-red-500/10 text-red-500 rounded-2xl hover:bg-red-500 hover:text-white transition-all font-black text-xs uppercase tracking-widest">تسجيل الخروج ⬅</button>
      </aside>

      <main className="flex-1 overflow-y-auto p-12 custom-scrollbar">
        {activeMenu === 'content' && (
          <div className="animate-fade-in space-y-10">
            <header className="flex justify-between items-center">
              <div>
                <h2 className="text-4xl font-black">إضافة <span style={{ color: theme.secondary }}>محتوى تفاعلي</span></h2>
                <p className="text-gray-500 text-sm mt-1">اربط ملفات الميكروتك أو أضف سيرفرات بث خارجي لمشتركي الاستراحة.</p>
              </div>
              <div className="flex bg-white/5 p-1 rounded-2xl border border-white/10">
                 <button onClick={() => setSourceType('mikrotik')} className={`px-6 py-2 rounded-xl text-xs font-bold transition-all ${sourceType === 'mikrotik' ? 'bg-green-500 text-black' : 'text-gray-400'}`}>سيرفر الميكروتك</button>
                 <button onClick={() => setSourceType('external')} className={`px-6 py-2 rounded-xl text-xs font-bold transition-all ${sourceType === 'external' ? 'bg-blue-500 text-white' : 'text-gray-400'}`}>سيرفر خارجي (IPTV)</button>
              </div>
            </header>

            <div className="bg-white/[0.02] border border-white/10 p-10 rounded-[45px] grid grid-cols-12 gap-8 shadow-2xl relative overflow-hidden">
               <div className="absolute top-0 right-0 w-32 h-32 bg-green-500/10 blur-3xl"></div>
               
               <div className="col-span-7 space-y-5">
                  <div className="space-y-2">
                     <label className="text-[10px] font-black text-gray-500 uppercase mr-4">عنوان المحتوى</label>
                     <input type="text" placeholder="مثلاً: الأهلي ضد الزمالك / فيلم هاري بوتر" value={newItem.title || ''} onChange={e => setNewItem({...newItem, title: e.target.value})} className="w-full bg-black/60 border border-white/10 p-5 rounded-2xl outline-none focus:border-green-500 transition-all text-lg font-bold" />
                  </div>
                  
                  <div className="space-y-2">
                     <label className="text-[10px] font-black text-gray-500 uppercase mr-4">رابط البث (URL)</label>
                     <div className="relative">
                        <input type="text" placeholder={sourceType === 'mikrotik' ? 'http://192.168.88.10/movies/film.mp4' : 'http://server-ip:port/stream...'} value={newItem.streamUrl || ''} onChange={e => setNewItem({...newItem, streamUrl: e.target.value})} className="w-full bg-black/60 border border-white/10 p-5 rounded-2xl outline-none focus:border-blue-500 font-mono text-sm" />
                        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-xl">{sourceType === 'mikrotik' ? '📟' : '🌐'}</span>
                     </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                     <div className="space-y-2">
                        <label className="text-[10px] font-black text-gray-500 uppercase mr-4">التصنيف</label>
                        <input type="text" placeholder="دراما، رياضة..." value={newItem.category || ''} onChange={e => setNewItem({...newItem, category: e.target.value})} className="w-full bg-black/60 border border-white/10 p-4 rounded-2xl outline-none" />
                     </div>
                     <div className="space-y-2">
                        <label className="text-[10px] font-black text-gray-500 uppercase mr-4">نوع المادة</label>
                        <select value={newItem.type} onChange={e => setNewItem({...newItem, type: e.target.value as any})} className="w-full bg-black/60 border border-white/10 p-4 rounded-2xl outline-none appearance-none cursor-pointer">
                          <option value="movie">فيلم محلي 🎬</option>
                          <option value="match">بث مباشر ⚽</option>
                          <option value="series">مسلسل 📺</option>
                        </select>
                     </div>
                  </div>
               </div>

               <div className="col-span-5 space-y-5 flex flex-col justify-between">
                  <div className="space-y-2">
                     <label className="text-[10px] font-black text-gray-500 uppercase mr-4">صورة البوستر (رابط)</label>
                     <input type="text" placeholder="https://image-url.jpg" value={newItem.poster || ''} onChange={e => setNewItem({...newItem, poster: e.target.value})} className="w-full bg-black/60 border border-white/10 p-4 rounded-2xl outline-none mb-4" />
                     <div className="w-full h-40 bg-black/40 rounded-2xl border border-white/5 overflow-hidden flex items-center justify-center text-gray-600 relative group">
                        {newItem.poster ? <img src={newItem.poster} className="w-full h-full object-cover" /> : <span className="text-3xl">🖼️</span>}
                        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-[10px] font-black uppercase">معاينة البوستر</div>
                     </div>
                  </div>

                  <button 
                    onClick={handleAddItem} 
                    className="w-full py-5 rounded-2xl font-black text-black transition-all hover:scale-[1.02] shadow-[0_20px_40px_rgba(0,0,0,0.3)] flex items-center justify-center gap-3" 
                    style={{ backgroundColor: sourceType === 'mikrotik' ? theme.secondary : '#00D4FF' }}
                  >
                     <span>{sourceType === 'mikrotik' ? 'نشر من الميكروتك' : 'بدء البث الحي'}</span>
                     <span className="text-xl">🚀</span>
                  </button>
               </div>
            </div>

            <div className="space-y-6">
               <h3 className="text-xl font-black flex items-center gap-3">
                  <span className="w-8 h-1 bg-green-500 rounded-full"></span>
                  المحتوى المنشور حالياً
               </h3>
               <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                 {items.map(item => (
                   <div key={item.id} className="bg-white/5 rounded-3xl overflow-hidden border border-white/5 group relative flex flex-col">
                     <div className="relative h-44">
                        <img src={item.poster} className="w-full h-full object-cover opacity-60 group-hover:opacity-100 transition-all duration-700" />
                        <div className="absolute top-4 right-4 flex gap-2">
                           <button onClick={() => removeItem(item.id)} className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center text-white text-xs hover:scale-110 transition-all shadow-lg">✖</button>
                        </div>
                        {item.type === 'match' && <div className="absolute bottom-4 left-4 px-3 py-1 bg-red-600 rounded-lg text-[9px] font-black animate-pulse shadow-lg">LIVE</div>}
                     </div>
                     <div className="p-6">
                       <h4 className="font-bold text-lg leading-tight mb-2 truncate">{item.title}</h4>
                       <p className="text-[10px] text-gray-500 font-black uppercase tracking-widest">{item.category}</p>
                     </div>
                   </div>
                 ))}
               </div>
            </div>
          </div>
        )}

        {activeMenu === 'mikrotik' && (
           <div className="space-y-10 animate-fade-in text-center py-20">
              <div className="w-32 h-32 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-8 border border-white/10">
                 <span className="text-6xl">📟</span>
              </div>
              <h2 className="text-4xl font-black uppercase tracking-tighter">MikroTik File Manager</h2>
              <p className="text-gray-500 max-w-lg mx-auto">سيتم استعراض ملفات المجلد <code className="bg-black/40 px-2 py-1 rounded text-green-500">/flash/media</code> هنا في التحديث القادم للربط المباشر مع API الراوتر.</p>
           </div>
        )}
      </main>
    </div>
  );
};

const AdminNavItem = ({ label, icon, active, onClick, color }: any) => (
  <button onClick={onClick} className={`w-full flex items-center gap-4 px-6 py-4 rounded-2xl transition-all ${active ? 'bg-white/5 border border-white/10 shadow-xl' : 'text-gray-500 hover:bg-white/5'}`}>
    <span className="text-xl" style={active ? { filter: `drop-shadow(0 0 10px ${color})` } : {}}>{icon}</span>
    <span className={`font-bold text-sm ${active ? 'text-white' : ''}`}>{label}</span>
  </button>
);

export default AdminDashboard;
