
import React from 'react';
import { MatchSchedule } from '../types';

interface Props {
  items: MatchSchedule[];
  extended?: boolean;
}

const LiveMatches: React.FC<Props> = ({ items, extended }) => {
  return (
    <div className={`grid gap-3 ${extended ? 'grid-cols-1 md:grid-cols-2' : ''}`}>
      {items.map(match => (
        <div key={match.id} className="bg-[#1a1a1a] border border-gray-800 p-4 rounded-xl flex items-center justify-between hover:border-[#d4af37]/50 transition-colors">
          <div className="flex items-center gap-4">
             <div className="w-10 h-10 bg-[#252525] rounded-full flex items-center justify-center text-xl">
               ⚽
             </div>
             <div>
               <h4 className="font-bold text-gray-200">{match.teams}</h4>
               <p className={`text-[10px] font-bold flex items-center gap-1 ${match.status === 'live' ? 'text-red-500' : 'text-gray-500'}`}>
                 {match.status === 'live' && <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>}
                 {match.time}
               </p>
             </div>
          </div>
          <button className="gold-bg text-black text-xs font-bold px-4 py-2 rounded-lg hover:brightness-110">
            {match.status === 'live' ? 'شاهد الآن' : 'تذكير'}
          </button>
        </div>
      ))}
    </div>
  );
};

export default LiveMatches;
