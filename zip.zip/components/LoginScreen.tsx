
import React, { useState } from 'react';
import Logo from './Logo';
import { ThemeColors, InternetPackage } from '../types';

interface Props {
  theme: ThemeColors;
  onLogin: (username: string, speedType: string) => void;
  onAdminLink: () => void;
}

const SPEED_OPTIONS = [
  { id: 'standard', label: 'سرعة عادية', desc: 'للتصفح والبث المحلي المجاني', icon: '📶', color: '#94a3b8' },
  { id: 'high', label: 'سرعة عالية', desc: 'ألعاب اونلاين وبث HD', icon: '⚡', color: '#00D4FF' },
  { id: 'turbo', label: 'سرعة توربو', desc: 'بث 4K وتحميل فائق السرعة', icon: '🚀', color: '#00FF41' },
];

const PACKAGES: InternetPackage[] = [
  { id: '1', name: 'الباقة البرونزية', quota: '2 GB', duration: '24 ساعة', price: '500 ريال', color: '#cd7f32' },
  { id: '2', name: 'الباقة الفضية', quota: '10 GB', duration: '7 أيام', price: '2000 ريال', color: '#C0C0C0' },
  { id: '3', name: 'الباقة الذهبية', quota: '30 GB', duration: '30 يوم', price: '5000 ريال', color: '#FFD700' },
  { id: '4', name: 'باقة ملوك حماس (VIP)', quota: 'مفتوح', duration: '30 يوم', price: '10000 ريال', color: '#00FF41' },
];

const LoginScreen: React.FC<Props> = ({ theme, onLogin, onAdminLink }) => {
  const [step, setStep] = useState<1 | 2>(1);
  const [selectedSpeed, setSelectedSpeed] = useState<string | null>(null);
  const [voucher, setVoucher] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleNextStep = (speedId: string) => {
    setSelectedSpeed(speedId);
    setStep(2);
  };

  const handleLogin = () => {
    if (!voucher) return;
    setLoading(true);
    // تأخير محاكي لعملية التحقق لإضفاء طابع تقني
    setTimeout(() => onLogin(voucher, selectedSpeed || 'standard'), 1500);
  };

  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center p-4 lg:p-10 font-['Cairo'] overflow-hidden bg-[#020617]">
      
      {/* Cinematic Background Atmosphere */}
      <div className="absolute top-[-20%] left-[-10%] w-[800px] h-[800px] rounded-full blur-[180px] opacity-30 animate-pulse" style={{ backgroundColor: `${theme.primary}22` }}></div>
      <div className="absolute bottom-[-20%] right-[-10%] w-[800px] h-[800px] rounded-full blur-[180px] opacity-30 animate-pulse" style={{ backgroundColor: `${theme.secondary}22` }}></div>
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-[0.03]"></div>

      <div className="w-full max-w-7xl grid grid-cols-1 lg:grid-cols-12 gap-12 relative z-10 items-center">
        
        {/* Left Side: Dynamic Login Flow */}
        <div className="lg:col-span-5 flex flex-col gap-10">
           <div className="bg-white/[0.02] backdrop-blur-3xl border border-white/10 p-12 rounded-[60px] shadow-[0_50px_100px_rgba(0,0,0,0.7)] relative overflow-hidden group">
              {/* Subtle glass reflection overlay */}
              <div className="absolute inset-0 bg-gradient-to-br from-white/[0.05] to-transparent pointer-events-none"></div>

              <div className="flex justify-center mb-10 relative">
                 <Logo size={step === 1 ? 140 : 110} theme={theme} className="transition-all duration-700" />
              </div>
              
              {step === 1 ? (
                <div className="animate-fade-in">
                   <h2 className="text-3xl font-black text-center text-white mb-2 leading-tight">بوابة <span style={{ color: theme.secondary }}>التحكم بالسرعة</span></h2>
                   <p className="text-gray-500 text-[10px] text-center font-bold uppercase tracking-[0.3em] mb-10">Select your connection tier</p>
                   
                   <div className="space-y-4">
                      {SPEED_OPTIONS.map(opt => (
                        <button
                          key={opt.id}
                          onClick={() => handleNextStep(opt.id)}
                          className="w-full bg-white/[0.03] border border-white/5 p-6 rounded-[30px] flex items-center gap-6 hover:bg-white/10 hover:border-white/20 hover:scale-[1.03] transition-all text-right group/btn relative overflow-hidden"
                        >
                          <div className="text-3xl p-4 rounded-2xl bg-black/50 group-hover/btn:bg-black/80 transition-all shadow-xl" style={{ textShadow: `0 0 20px ${opt.color}` }}>{opt.icon}</div>
                          <div className="flex-1">
                             <p className="font-black text-white text-lg">{opt.label}</p>
                             <p className="text-[10px] text-gray-500 font-bold">{opt.desc}</p>
                          </div>
                          <div className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center text-sm opacity-30 group-hover/btn:opacity-100 transition-opacity">⬅</div>
                        </button>
                      ))}
                   </div>
                </div>
              ) : (
                <div className="animate-fade-in">
                   <div className="flex items-center justify-between mb-10 bg-black/40 p-4 rounded-[25px] border border-white/5 shadow-inner">
                      <div className="flex items-center gap-4">
                         <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-2xl shadow-lg">
                            {SPEED_OPTIONS.find(o => o.id === selectedSpeed)?.icon}
                         </div>
                         <div className="flex flex-col">
                            <span className="text-[10px] font-black text-gray-500 uppercase">وضع السرعة</span>
                            <span className="text-xs font-black text-white">{SPEED_OPTIONS.find(o => o.id === selectedSpeed)?.label}</span>
                         </div>
                      </div>
                      <button onClick={() => setStep(1)} className="text-[10px] font-black text-gray-400 hover:text-white underline px-4 py-2 hover:bg-white/5 rounded-xl transition-all uppercase">تعديل</button>
                   </div>

                   <div className="text-center mb-10">
                      <h1 className="text-4xl font-black text-white mb-2">رمز <span style={{ color: theme.secondary }}>العبور</span></h1>
                      <p className="text-gray-500 text-[10px] font-bold uppercase tracking-widest">Enter your access voucher code</p>
                   </div>
                   
                   <div className="space-y-8 relative">
                      {/* Luxury Voucher Input */}
                      <div className="relative group">
                         <div className={`absolute inset-0 blur-[20px] rounded-3xl transition-all duration-500 ${isFocused ? 'opacity-40' : 'opacity-0'}`} style={{ backgroundColor: theme.secondary }}></div>
                         <input
                           type="text"
                           value={voucher}
                           onFocus={() => setIsFocused(true)}
                           onBlur={() => setIsFocused(false)}
                           onChange={(e) => setVoucher(e.target.value)}
                           placeholder="•••• •••• ••••"
                           className="w-full bg-black/60 border border-white/10 rounded-[30px] py-8 px-8 text-center text-3xl font-black tracking-[0.2em] text-white focus:border-green-500/50 outline-none transition-all relative z-10 shadow-[inset_0_2px_15px_rgba(0,0,0,0.5)] placeholder:opacity-20 uppercase"
                         />
                         {voucher && (
                            <div className="absolute right-6 top-1/2 -translate-y-1/2 z-20 animate-fade-in">
                               <span className="text-green-500 text-xl font-black">✓</span>
                            </div>
                         )}
                      </div>

                      {/* Prominent Neon Action Button */}
                      <button
                        onClick={handleLogin}
                        disabled={loading || !voucher}
                        className="w-full py-7 rounded-[30px] font-black text-xl text-black transition-all active:scale-95 shadow-[0_20px_40px_rgba(0,0,0,0.4)] relative overflow-hidden group/submit disabled:opacity-50 disabled:grayscale"
                        style={{ 
                          backgroundColor: theme.secondary,
                          boxShadow: `0 15px 35px ${theme.secondary}44`
                        }}
                      >
                        <div className="absolute inset-0 bg-white/20 translate-y-full group-hover/submit:translate-y-0 transition-transform duration-500"></div>
                        <div className="relative z-10 flex items-center justify-center gap-4">
                           {loading ? (
                             <>
                               <div className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin"></div>
                               <span>جاري المصادقة...</span>
                             </>
                           ) : (
                             <>
                               <span>دخول الشبكة</span>
                               <span className="text-2xl">⚡</span>
                             </>
                           )}
                        </div>
                      </button>
                      
                      <div className="flex items-center justify-center gap-2 text-[10px] font-black text-gray-600 uppercase tracking-widest">
                         <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span>
                         اتصال آمن ومحمي
                      </div>
                   </div>
                </div>
              )}

              <div className="flex justify-center gap-8 mt-12 border-t border-white/5 pt-8">
                 <button onClick={onAdminLink} className="text-[9px] font-black text-gray-500 hover:text-white transition-all uppercase tracking-[0.3em] flex items-center gap-2 group">
                    <span className="opacity-0 group-hover:opacity-100 transition-opacity">🛡️</span>
                    بوابة الإدارة المركزية
                 </button>
              </div>
           </div>

           <div className="grid grid-cols-2 gap-6 px-4">
              <ContactCard label="المساعدة الفنية" value="777-123-456" icon="📞" theme={theme} />
              <ContactCard label="مركز الاستعلامات" value="733-999-000" icon="📡" theme={theme} />
           </div>
        </div>

        {/* Right Side: Luxury Packages Display */}
        <div className="lg:col-span-7 space-y-10">
           <div className="flex flex-col gap-2 px-6">
              <h2 className="text-4xl font-black text-white leading-none">باقات <span style={{ color: theme.secondary }}>الاشتراك النخبوية</span></h2>
              <p className="text-gray-500 font-bold uppercase tracking-[0.4em] text-[10px]">Premium Internet Access Packages</p>
           </div>
           
           <div className="grid grid-cols-1 md:grid-cols-2 gap-8 overflow-y-auto max-h-[75vh] pr-4 custom-scrollbar pb-10">
              {PACKAGES.map(pkg => (
                 <div key={pkg.id} className="bg-white/[0.02] border border-white/5 p-10 rounded-[50px] hover:bg-white/[0.05] transition-all group relative overflow-hidden flex flex-col justify-between h-72 shadow-xl hover:-translate-y-2">
                    <div className="absolute top-0 right-0 w-48 h-48 blur-[80px] opacity-10 rounded-full transition-opacity group-hover:opacity-20" style={{ backgroundColor: pkg.color }}></div>
                    <div className="relative z-10">
                       <div className="flex justify-between items-start mb-8">
                          <span className="text-[10px] font-black uppercase px-4 py-1.5 rounded-full border border-white/10 tracking-widest" style={{ color: pkg.color, backgroundColor: `${pkg.color}11` }}>{pkg.name}</span>
                          <span className="text-3xl opacity-50 group-hover:opacity-100 transition-opacity">📶</span>
                       </div>
                       <div className="flex items-baseline gap-2">
                          <h3 className="text-5xl font-black text-white tracking-tighter">{pkg.price.split(' ')[0]}</h3>
                          <span className="text-sm font-black text-gray-500 uppercase">{pkg.price.split(' ')[1]}</span>
                       </div>
                    </div>
                    
                    <div className="relative z-10 flex justify-between items-end border-t border-white/5 pt-6 mt-6">
                       <div className="space-y-1">
                          <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">رصيد البيانات</p>
                          <p className="text-xl font-black text-white">{pkg.quota}</p>
                       </div>
                       <div className="text-left space-y-1">
                          <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">الصلاحية</p>
                          <p className="text-sm font-black text-gray-300">{pkg.duration}</p>
                       </div>
                    </div>
                 </div>
              ))}
           </div>
        </div>
      </div>
    </div>
  );
};

const ContactCard = ({ label, value, icon, theme }: any) => (
  <div className="bg-white/[0.03] border border-white/5 p-6 rounded-[30px] flex items-center gap-5 hover:bg-white/10 transition-all group cursor-pointer shadow-lg">
    <div className="text-2xl p-3 rounded-2xl bg-black/40 group-hover:scale-110 transition-transform">{icon}</div>
    <div>
      <p className="text-[9px] font-black text-gray-500 uppercase tracking-widest mb-1">{label}</p>
      <p className="text-xs font-black text-white group-hover:text-green-400 transition-colors">{value}</p>
    </div>
  </div>
);

export default LoginScreen;
