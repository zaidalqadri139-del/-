
import React from 'react';
import { ThemeColors } from '../types';
import Logo from './Logo';

interface Props {
  theme: ThemeColors;
}

const SplashScreen: React.FC<Props> = ({ theme }) => {
  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center bg-[#020617] z-[100]">
      {/* Animated Orbit Background */}
      <div className="absolute w-[400px] h-[400px] border border-white/5 rounded-full animate-ping opacity-20"></div>
      
      <div className="relative flex items-center justify-center">
        {/* Loading Ring */}
        <div 
          className="absolute w-48 h-48 border-4 border-t-transparent rounded-full animate-spin" 
          style={{ borderColor: theme.secondary }}
        ></div>
        
        {/* Official Logo in Center */}
        <Logo size={140} theme={theme} />
      </div>

      <div className="mt-16 text-center animate-fade-in">
        <h1 className="text-4xl font-black mb-2 tracking-tighter" style={{ color: '#fff' }}>
          شبكة <span style={{ color: '#00FF41' }}>حماس</span>
        </h1>
        <p className="text-gray-500 font-bold uppercase tracking-[0.4em] text-[10px]">Hamas Network • The Ultimate Hub</p>
      </div>

      <div className="absolute bottom-12 flex items-center gap-3">
         <div className="w-1.5 h-1.5 bg-[#00FF41] rounded-full animate-bounce" style={{ animationDelay: '0s' }}></div>
         <div className="w-1.5 h-1.5 bg-[#00FF41] rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
         <div className="w-1.5 h-1.5 bg-[#00FF41] rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
      </div>
    </div>
  );
};

export default SplashScreen;
