
import React, { useState } from 'react';
import { ThemeColors } from '../types';

interface Props {
  theme: ThemeColors;
  onLogin: () => void;
  onBack: () => void;
}

const AdminLogin: React.FC<Props> = ({ theme, onLogin, onBack }) => {
  const [pass, setPass] = useState('');

  return (
    <div className="flex flex-col items-center justify-center min-h-screen px-6 bg-[#020617] font-['Cairo'] relative overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] blur-[200px] opacity-20 rounded-full" style={{ backgroundColor: theme.primary }}></div>
      
      <div className="w-full max-w-md bg-white/[0.03] backdrop-blur-3xl p-12 rounded-[50px] shadow-2xl border border-white/10 relative z-10">
        <div className="text-center mb-10">
          <div className="w-20 h-20 rounded-[25px] flex items-center justify-center mx-auto mb-6 shadow-2xl" style={{ backgroundColor: theme.secondary }}>
             <span className="text-4xl text-black">🔒</span>
          </div>
          <h2 className="text-3xl font-black text-white mb-2">غرفة التحكم</h2>
          <p className="text-gray-500 text-xs font-bold uppercase tracking-widest">Administrator Access Only</p>
        </div>

        <div className="space-y-6">
          <input
            type="password"
            value={pass}
            onChange={(e) => setPass(e.target.value)}
            placeholder="كلمة مرور المسؤول"
            className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 px-6 text-center text-white focus:border-green-500 outline-none transition-all shadow-inner"
          />
          <button
            onClick={onLogin}
            className="w-full font-black py-4 rounded-2xl transition-all shadow-2xl hover:brightness-110 active:scale-95"
            style={{ backgroundColor: theme.secondary, color: '#000' }}
          >
            فتح البوابة الأمانية
          </button>
        </div>

        <button 
          onClick={onBack} 
          className="mt-10 text-gray-500 text-xs font-black hover:text-white block mx-auto transition-colors flex items-center gap-2"
        >
          <span>⬅</span> العودة للواجهة الرئيسية
        </button>
      </div>
    </div>
  );
};

export default AdminLogin;
