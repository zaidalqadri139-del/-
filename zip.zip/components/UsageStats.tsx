
import React from 'react';
import { AppUsage } from '../types';

interface Props {
  items: AppUsage[];
}

const UsageStats: React.FC<Props> = ({ items }) => {
  return (
    <div className="space-y-6">
      {items.map((item, idx) => (
        <div key={idx} className="space-y-2">
          <div className="flex justify-between items-center text-sm">
            <div className="flex items-center gap-3">
              <span className="text-2xl">{item.icon}</span>
              <span className="font-bold">{item.appName}</span>
            </div>
            <div className="text-right">
              <span className="font-bold text-gray-200">{item.dataUsed}</span>
              <span className="text-[10px] text-gray-500 block">وقت الاستخدام: {item.timeSpent}</span>
            </div>
          </div>
          <div className="w-full bg-[#252525] h-2 rounded-full overflow-hidden">
            <div 
              className="h-full bg-[#d4af37] rounded-full" 
              style={{ width: `${item.percentage}%`, boxShadow: '0 0 10px rgba(212, 175, 55, 0.4)' }}
            ></div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default UsageStats;
