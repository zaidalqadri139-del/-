
import React from 'react';
import { ThemeColors } from '../types';

interface LogoProps {
  size?: number;
  theme: ThemeColors;
  className?: string;
}

const Logo: React.FC<LogoProps> = ({ size = 100, theme, className = "" }) => {
  // استخدام رابط الصورة المرفقة (سيفترض النظام وجودها كـ logo.png أو رابط مباشر)
  // في هذه البيئة سنستخدم الصورة التي تظهر في السياق
  const logoUrl = "https://files.oaiusercontent.com/file-K1P9I9I9I9I9I9I9I9I9I9I9"; // هذا الرابط تمثيلي، سنعتمد على التصميم الدائري

  return (
    <div className={`relative flex items-center justify-center ${className}`} style={{ width: size, height: size }}>
      {/* Dynamic Glow Layer */}
      <div 
        className="absolute inset-0 blur-[30px] rounded-full animate-pulse" 
        style={{ 
          backgroundColor: '#00FF41', // التوهج بالأخضر المميز في الشعار
          opacity: 0.25 
        }}
      ></div>
      
      {/* Logo Container with Glass Effect */}
      <div className="relative w-full h-full rounded-full border border-white/10 overflow-hidden bg-white shadow-2xl">
        <img 
          src="https://img.freepik.com/free-vector/bird-dove-peace-flying-olive-branch_1284-43118.jpg?t=st=1740000000~exp=1740003600~hmac=..." // سيتم تعويضها بالشعار المرفق
          alt="Hamas Network Logo"
          className="w-full h-full object-cover scale-95"
          onError={(e) => {
            // fallback in case of image error: showing a styled H
            e.currentTarget.src = "https://i.ibb.co/LdpX9zP/hamas-logo-placeholder.png";
          }}
        />
        {/* Overlay reflection for glass look */}
        <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-transparent"></div>
      </div>
      
      {/* Outer Neon Ring */}
      <div className="absolute inset-[-5%] rounded-full border-2 border-dashed border-[#00FF41]/30 animate-[spin_15s_linear_infinite]"></div>
    </div>
  );
};

export default Logo;
