
import React from 'react';
import { ContentItem, AppUsage, MatchSchedule } from './types';

export const COLORS = {
  bg: '#0c0c0c',
  card: '#1a1a1a',
  gold: '#d4af37',
  goldDark: '#b49431',
  text: '#e5e7eb',
};

export const MOCK_MOVIES: ContentItem[] = [
  {
    id: '1',
    title: 'الملحمة الكبرى',
    description: 'فيلم درامي أكشن يحكي قصة صراع البقاء في البراري.',
    poster: 'https://picsum.photos/seed/movie1/400/600',
    type: 'movie',
    category: 'أكشن',
    streamUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
    isFree: true,
    year: 2024,
    duration: '2h 15m',
    // Added createdAt property
    createdAt: 1710000000000
  },
  {
    id: '2',
    title: 'غموض القاهرة',
    description: 'محقق يحاول حل لغز اختفاء غامض في شوارع القاهرة القديمة.',
    poster: 'https://picsum.photos/seed/movie2/400/600',
    type: 'movie',
    category: 'تشويق',
    streamUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
    isFree: true,
    year: 2023,
    duration: '1h 45m',
    // Added createdAt property
    createdAt: 1710000000000
  },
  {
    id: '3',
    title: 'سباق القمة',
    description: 'فيلم وثائقي عن أشهر متسلقي الجبال في العالم.',
    poster: 'https://picsum.photos/seed/movie3/400/600',
    type: 'movie',
    category: 'وثائقي',
    streamUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
    isFree: true,
    year: 2024,
    duration: '1h 20m',
    // Added createdAt property
    createdAt: 1710000000000
  },
  {
    id: '4',
    title: 'حب فوق السحاب',
    description: 'قصة حب تنشأ بين طيار ومضيفة في رحلة غير متوقعة.',
    poster: 'https://picsum.photos/seed/movie4/400/600',
    type: 'movie',
    category: 'رومانسي',
    streamUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
    isFree: true,
    year: 2023,
    duration: '1h 55m',
    // Added createdAt property
    createdAt: 1710000000000
  }
];

export const MOCK_USAGE: AppUsage[] = [
  { appName: 'TikTok', dataUsed: '3.4 GB', timeSpent: '4h 30m', icon: '📱', percentage: 45 },
  { appName: 'YouTube', dataUsed: '2.1 GB', timeSpent: '2h 15m', icon: '🎬', percentage: 28 },
  { appName: 'Facebook', dataUsed: '850 MB', timeSpent: '1h 45m', icon: '👥', percentage: 12 },
  { appName: 'Chrome', dataUsed: '420 MB', timeSpent: '50m', icon: '🌐', percentage: 8 },
];

export const MOCK_MATCHES: MatchSchedule[] = [
  { id: 'm1', teams: 'الأهلي × الزمالك', time: '20:00', status: 'upcoming', streamUrl: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8' },
  { id: 'm2', teams: 'ريال مدريد × برشلونة', time: 'مباشر الآن', status: 'live', streamUrl: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8' },
  { id: 'm3', teams: 'ليفربول × مانشستر سيتي', time: '22:30', status: 'upcoming', streamUrl: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8' },
];
