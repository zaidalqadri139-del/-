
export enum AppView {
  USER_SPLASH,
  USER_LOGIN,
  USER_DASHBOARD,
  USER_PLAYER,
  ADMIN_LOGIN,
  ADMIN_DASHBOARD
}

export interface ThemeColors {
  primary: string;
  secondary: string;
  accent: string;
  glow: string;
}

export interface ContentItem {
  id: string;
  title: string;
  description: string;
  poster: string;
  type: 'movie' | 'series' | 'match' | 'ad';
  category: string;
  streamUrl: string;
  isFree: boolean;
  year?: number;
  duration?: string;
  createdAt: number;
}

export interface UserSession {
  username: string;
  balance: string;
  expiry: string;
  ipAddress: string;
  macAddress: string;
  speedType: string;
}

export interface AppUsage {
  appName: string;
  dataUsed: string;
  timeSpent: string;
  icon: string;
  percentage: number;
}

// Added missing interface MatchSchedule
export interface MatchSchedule {
  id: string;
  teams: string;
  time: string;
  status: 'live' | 'upcoming';
  streamUrl: string;
}

// Added missing interface InternetPackage
export interface InternetPackage {
  id: string;
  name: string;
  quota: string;
  duration: string;
  price: string;
  color: string;
}

// Added missing interface ServerNode
export interface ServerNode {
  id: string;
  name: string;
  status: 'online' | 'offline';
  load: number;
}
